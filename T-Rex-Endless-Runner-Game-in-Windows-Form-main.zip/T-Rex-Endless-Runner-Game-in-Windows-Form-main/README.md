# C# Tutorial - Make a simple T Rex Endless runner game in Windows Form and Visual Studio

In this tutorial we are going to make a simple endless runner similar to the dinosaur game from chrome browser. This is a endless runner so the objective of this game is to jump over the obstacles and score as high as possible. 

We are making this game in visual studio with windows form and c# programming language. In this game we will use label, picture boxes and timer. Download the images from the link above and you follow along the tutorial as we will make this game scratch. We will go over some of the core programming techniques such as resetting the game so you can play again, timer event, key down and key up event inside of windows form. Its a fun little game to practice programming with. I hope you find it useful. 

Video Tutorial - 

[![](http://img.youtube.com/vi/35RTKAFDjY0/0.jpg)](http://www.youtube.com/watch?v=35RTKAFDjY0 "MOO ICT t rex runner game in windows form")

Written Tutorial - 

https://www.mooict.com/c-tutorial-create-a-t-rex-endless-runner-game-in-visual-studio/
